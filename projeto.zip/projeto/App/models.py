from django.db import models

class Professores(models.Model):
    id_professor = models.AutoField(primary_key = True)
    nome = models.CharField(max_length = 225)
    cpf = models.CharField(max_length = 11)
    rg = models.CharField(max_length = 8)
    codigo = models.CharField(max_length = 8)
    email = models.CharField(max_length = 255)
    telefone = models.CharField(max_length = 11)

class Disciplinas(models.Model):
    id_disciplina = models.AutoField(primary_key = True)
    id_professor = models.ForeignKey(Professores, on_delete = models.CASCADE)
    nome = models.CharField(max_length = 225)
    codigo = models.CharField(max_length = 7)
    carga_horaria = models.IntegerField()
    ementa = models.TextField(null = True)

class Alunos(models.Model):
    id_aluno = models.AutoField(primary_key = True)
    nome = models.CharField(max_length = 225)
    cpf = models.CharField(max_length = 11)
    rg = models.CharField(max_length = 8)
    matricula = models.CharField(max_length = 8)
    telefone = models.CharField(max_length = 255)
    email = models.CharField(max_length = 11)

class Frequencia(models.Model):
    id_frequencia = models.AutoField(primary_key = True)
    id_materia = models.ForeignKey(Disciplinas, on_delete = models.CASCADE)
    dia = models.DateField(auto_now_add = True)

class FrequenciaAluno(models.Model):
    id = models.AutoField(primary_key = True)
    id_aluno = models.ForeignKey(Alunos, on_delete = models.CASCADE)
    id_frequencia = models.ForeignKey(Frequencia, on_delete = models.CASCADE)
    presenca = models.BooleanField(max_length = 1,default = True)

class DisciplinaAluno(models.Model):
    id_matricula = models.AutoField(primary_key = True)
    id_aluno = models.ForeignKey(Alunos, on_delete = models.CASCADE)
    id_disciplina = models.ForeignKey(Disciplinas, on_delete = models.CASCADE)
    nota = models.FloatField()

class PlanoAula(models.Model):
    choice_metodo = (("Teorica","Teorica"),("Prática","Prática"))
    id_plano_aula = models.AutoField(primary_key = True)
    id_disciplina = models.ForeignKey(Disciplinas, on_delete = models.CASCADE)
    tema_aula = models.CharField(max_length = 255)
    conteudo = models.TextField()
    metodo = models.CharField(max_length = 50)
    dia = models.DateField(auto_now_add = True)

class Atividades(models.Model):
    choice_tipo = (("Atividade de sala","Atividade de sala"),("Atividade de casa","Atividade de casa"),("Prova","Prova"))
    id_atividade = models.AutoField(primary_key = True)
    atividade = models.TextField()
    tipo = models.CharField(max_length = 50, choices = choice_tipo)
    data_postagem = models.DateField(auto_now_add = True)
    data_entrega = models.DateField(null = True)
    id_disciplina = models.ForeignKey(Disciplinas, on_delete = models.CASCADE)
    id_plano_aula = models.ForeignKey(PlanoAula, on_delete = models.CASCADE)

class AtividadeAluno(models.Model):
    id = models.AutoField(primary_key = True)
    id_atividade = models.ForeignKey(Atividades, on_delete = models.CASCADE)
    id_aluno = models.ForeignKey(Alunos, on_delete = models.CASCADE)
    nota = models.FloatField()