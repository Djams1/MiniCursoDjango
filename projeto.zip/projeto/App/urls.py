from rest_framework import routers
from .views import *

routerApp = routers.DefaultRouter()

routerApp.register(r'professores',ProfessoresView)
routerApp.register(r'disciplinas',ProfessoresView)
routerApp.register(r'alunos',ProfessoresView)
routerApp.register(r'frequencia',ProfessoresView)
routerApp.register(r'frequenciaAluno',ProfessoresView)
routerApp.register(r'disciplinaaluno',ProfessoresView)
routerApp.register(r'planoaula',ProfessoresView)
routerApp.register(r'atividades',ProfessoresView)
routerApp.register(r'atividades',ProfessoresView)
